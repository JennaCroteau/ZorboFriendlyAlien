# -*- coding: utf-8 -*-
"""
Image Generation for Zorbo Stimuli

Author: Jenna Croteau
Editor: Larry Liu

Date: 1/23/2023
Updated: 2/19/2025

Description:
    
    Code generates heterogenous & homogenous image arrays
"""

from PIL import Image
import random
import os
import math

# Read in names of every image in this directory
objectList = os.listdir('./object_stim')

imageObjectHet = "HeteroH"
# Constants
X_WIDTH = 500
Y_HEIGHT = 900
BACKGROUND_COLOR = (255, 255, 255)
ICON_SIZE = 180
ICON_SIZE_CIRCULAR = 100

# Generate a centered version of an image
# Parameters: Image, int, int
def create_im_centered(im, x_size, y_size):

    width, height = im.size
    im_thumb = im.copy()
    im_thumb.thumbnail((x_size, y_size))
    background = Image.new('RGBA', (x_size,y_size), BACKGROUND_COLOR)
    # find aspect ratio for original image
    if(max(width, height)) == width:
        aspect = height/width
        background.paste(im_thumb, (0, round(y_size * (1 - aspect) / 2)))
    else:
        aspect = width/height
        background.paste(im_thumb, (round(x_size * (1 - aspect) / 2), 0))

    return background

# Generate a list of coordinate tuples that represent where icons should be placed for a column layout
# ID: coln
# Parameters: int, bool
def column_coords(num, mirrored):
    if(num > 10):
        print("Warning: Script designed only for quantities of up to 10")        

    coords = list()
    
    # calculate offsets from sides of image
    x_offset = (X_WIDTH - ICON_SIZE * 2) / 2
    y_offset = 0

    if(num <= 5):
        x_offset = (X_WIDTH - ICON_SIZE) / 2
        y_offset = (Y_HEIGHT - num * ICON_SIZE) / 2

    # set up placements relative to other icons
    for i in range(0, min(num, 5)):
        if(mirrored and num > 5):
            coords.append((int(ICON_SIZE + x_offset),int(ICON_SIZE * i + y_offset)))
        else:
            coords.append((int(x_offset),int(ICON_SIZE * i + y_offset)))
    for i in range(5, num):
        if(mirrored):
            coords.append((int(x_offset),int(ICON_SIZE * (i-5) + y_offset)))    
        else:
            coords.append((int(ICON_SIZE + x_offset),int(ICON_SIZE * (i-5) + y_offset)))    

    return coords

# Generate a list of coordinate tuples that represent where icons should be placed for a block layout
# ID: bloc
# Parameters: int, bool
def block_coords(num):
    if(num > 10):
        print("Warning: Script designed only for quantities of up to 10")        

    coords = list()
    
    # calculate offsets from sides of image
    centered_x_offset = (X_WIDTH - ICON_SIZE) / 2
    doubled_x_offset = (X_WIDTH - ICON_SIZE * 2) / 2
    y_offset = (Y_HEIGHT - num * ICON_SIZE // 2) / 2

    # set up placements relative to other icons
    # even
    if(num % 2 == 0):
        for i in range (0, (num // 2)):
            coords.append((int(doubled_x_offset),int(ICON_SIZE * i + y_offset)))
            coords.append((int(ICON_SIZE + doubled_x_offset),int(ICON_SIZE * i + y_offset)))
    else: #odd
        for i in range (0, (num - 1) // 2):
            coords.append((int(doubled_x_offset),int(ICON_SIZE * i + y_offset)))
            coords.append((int(ICON_SIZE + doubled_x_offset),int(ICON_SIZE * i + y_offset)))
        coords.append((int(centered_x_offset),int(ICON_SIZE * ((num-1) // 2) + y_offset)))

    return coords

# Generate a list of coordinate tuples that represent where icons should be placed for a circular layout
# ID: circ
# Parameters: int, bool
def circular_coords(num):
    if(num > 10):
        print("Warning: Script designed only for quantities of up to 10")        

    coords = list()

    center_x = X_WIDTH // 2
    center_y = Y_HEIGHT // 2

    # I LOVE TRIGONOMETRY
    # Calculate distance from origin each icon has to be (radius of circle)
    icon_diagonal = math.sqrt(pow((ICON_SIZE_CIRCULAR / 2), 2) * 2)
    radius = 1/(math.sin(math.radians(18))*2) * icon_diagonal * 1.75

    angle = -90 # start at the top

    # calculate offsets from sides of image
    x_offset = (X_WIDTH - ICON_SIZE_CIRCULAR * 2) / 2
    y_offset = 0

    if(num == 1):
        coords.append((center_x - ICON_SIZE_CIRCULAR // 2, center_y - ICON_SIZE_CIRCULAR // 2))
    else:
        for i in range(0, num):
            coords.append((center_x + int(math.cos(math.radians(angle)) * radius) - ICON_SIZE_CIRCULAR // 2, center_y + int(math.sin(math.radians(angle)) * radius - ICON_SIZE_CIRCULAR // 2))) # I LOVE TRIG
            angle = angle + 360 // num

    return coords
    
# fetch a 100-icon image, or generate it if it doesn't already exist
# Parameters: bool, string, bool
# Returns: PIL Image Object
def fetch_100_image(homo, heterovar, name, circ, fullsize):
    if(not homo):
        name = f"100Hetero{heterovar}.jpg"
    else:
        if(not name):
            name = random.sample(objectList, 1) 
        # name parameter only used if homogenous
        name = name.split('.')[0] + '.jpg' # split splits a string into a list of parts seperated by a delimiter (in this case .)
    if(os.path.isfile(f"./100_stim/{name}")):
        # open an image:
        im = Image.open(f"./100_stim/{name}").convert("RGBA")
        if(circ):
            return create_im_centered(im, ICON_SIZE_CIRCULAR, ICON_SIZE_CIRCULAR)
        else:
            return create_im_centered(im, ICON_SIZE, ICON_SIZE)

    # creates a square canvas with a white background
    new_im = Image.new('RGB', (500,500), BACKGROUND_COLOR)

    ob = [name.split('.')[0] + '.png']

    # iterate through a 10 by 10 grid with 45 spacing, to place my image
    # allows for a bit of whitespace a the margins
    for i in range(25,475,45):
        for j in range(25,475,45):
            # get an image
            if(not homo):
                ob = random.sample(objectList, 1) 
            # open an image:
            im = Image.open(f"./object_stim/{ob[0]}").convert("RGBA")
            # resize image
            im = create_im_centered(im, 45, 45)
            
            # paste the image at location i,j:
            new_im.paste(im, (i,j), im)

    newImageName = "100" + ob[0].split('.')[0] + ".jpg" # split splits a string into a list of parts seperated by a delimiter (in this case .)
    if(not homo):
        newImageName = f"100Hetero{heterovar}.jpg"
    new_im.save(f"./100_stim/{newImageName}")
    im = Image.open(f"./100_stim/{newImageName}").convert("RGBA")
    if(fullsize):
        return create_im_centered(im, X_WIDTH, X_WIDTH)

    if(circ):
        return create_im_centered(im, ICON_SIZE_CIRCULAR, ICON_SIZE_CIRCULAR)
    else:
        return create_im_centered(im, ICON_SIZE, ICON_SIZE)

def generate_image(count, icons, name, mirrored, placement, fullsize):
    # create image canvas
    new_im = Image.new('RGB', (X_WIDTH,Y_HEIGHT), BACKGROUND_COLOR)

    # prep each icon (open, resize, etc)
    imagelist = list()

    # determine what placement mode we want, and return list of coordinates
    if placement == "coln":
        locations = column_coords(count, False)
        if(mirrored):
            locations_mirrored = column_coords(count, True)
            new_im_mirrored = Image.new('RGB', (X_WIDTH,Y_HEIGHT), BACKGROUND_COLOR)
    elif placement == "bloc":
        locations = block_coords(count)
        mirrored = False # no functionality for mirroring for this orientation
    elif placement == "circ":
        locations = circular_coords(count)
        mirrored = False # no functionality for mirroring for this orientation
    else:
        print("Placement ID not found, defaulting to nonmirrored column")
        placement = "coln"
        locations = column_coords(count, False)
        mirrored = False

    # fullsize only applies if the count is one
    if(fullsize and count == 1):
        new_im.paste(icons[0], (0, (Y_HEIGHT - X_WIDTH) // 2), icons[0])
        if(mirrored):
            new_im_mirrored.paste(icons[0], locations_mirrored.pop(0), icons[0])
    else:
        # place images
        for b in range(0, count):
            new_im.paste(icons[b], locations.pop(0), icons[b])
            if(mirrored):
                new_im_mirrored.paste(icons[b], locations_mirrored.pop(0), icons[b])

    new_im.save(f"./out/{name}")
    if(mirrored):
        new_im_mirrored.save(f"./out/{name}_mirrored")
# Generate images with objects comprised of single images
# Parameters: bool, bool, bool, string, string
def generate_images(mirrored, placement):
    #Generate Homogenous
    for i in range(1, 11): # 11 because range in exclusive at the top
        for o in objectList:
            # prep each icon (open, resize, etc)
            imagelist = list()

            for b in range(1, i + 1):
                im = Image.open(f"./object_stim/{o}").convert("RGBA") # dunno if I need to do this in the loop but I'm too lazy to check
                if(placement == "circ"):
                    im = create_im_centered(im, ICON_SIZE_CIRCULAR, ICON_SIZE_CIRCULAR)
                else:
                    im = create_im_centered(im, ICON_SIZE, ICON_SIZE)
                imagelist.append(im)

            generate_image(i, imagelist, str(i) + o.split('.')[0] + ".jpg", mirrored, placement, False) #.split to get rid of the .png

            imagelist = list()
            for b in range(1, i + 1):
                # full size if it's only 100
                if(i == 1):
                    imagelist.append(fetch_100_image(True, None, o, placement == "circ", True))
                else:
                    imagelist.append(fetch_100_image(True, None, o, placement == "circ", False))
            if(i == 1):
                generate_image(i, imagelist, str(i * 100) + o.split('.')[0] + ".jpg", mirrored, placement, True) #.split to get rid of the .png
            else:
                generate_image(i, imagelist, str(i * 100) + o.split('.')[0] + ".jpg", mirrored, placement, False) #.split to get rid of the .png

    # # Generate Hetero
    # for i in range(1, 11): # 11 because range in exclusive at the top
    #     for variant in ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H']:
    #         # prep each icon (open, resize, etc)
    #         imagelist = list()
    #
    #         # 1 is redundant with singleimages
    #         if (i != 1):
    #             for b in range(1, i + 1):
    #                 o = random.sample(objectList, 1)
    #                 im = Image.open(f"./object_stim/{o[0]}").convert("RGBA") # dunno if I need to do this in the loop but I'm too lazy to check
    #                 if(placement == "circ"):
    #                     im = create_im_centered(im, ICON_SIZE_CIRCULAR, ICON_SIZE_CIRCULAR)
    #                 else:
    #                     im = create_im_centered(im, ICON_SIZE, ICON_SIZE)
    #                 imagelist.append(im)
    #
    #             generate_image(i, imagelist, str(i) + "Hetero" + variant + ".jpg", mirrored, placement, False) #.split to get rid of the .png
    #
    #         imagelist = list()
    #         for b in range(1, i + 1):
    #             # full size if it's only 100
    #             if(i == 1):
    #                 imagelist.append(fetch_100_image(False, variant, None, placement == "circ", True))
    #             else:
    #                 imagelist.append(fetch_100_image(False, variant, None, placement == "circ", False))
    #         if(i == 1):
    #             generate_image(i, imagelist, str(i * 100) + "Hetero" + variant + ".jpg", mirrored, placement, True) #.split to get rid of the .png
    #         else:
    #             generate_image(i, imagelist, str(i * 100) + "Hetero" + variant + ".jpg", mirrored, placement, False) #.split to get rid of the .png

# Params: mirrored, placement
generate_images(False, "coln")
