# -*- coding: utf-8 -*-
"""
Image Generation for Zorbo Stimuli

Author: Jenna Croteau
Editor: Larry Liu

Date: 1/23/2023
Updated: 2/19/2025

Description:
    
    Code generates heterogenous & homogenous image arrays
"""

from PIL import Image
import random
import os
import math

# Read in names of every image in this directory
objectList = os.listdir('./object_stim')

imageObjectHet = "HeteroH"
# Constants
X_WIDTH = 500
Y_HEIGHT = 900
BACKGROUND_COLOR = (255, 255, 255)
ICON_SIZE = 180
ICON_SIZE_CIRCULAR = 100

# Generate a centered version of an image
# Parameters: Image, int, int
def create_im_centered(im, x_size, y_size):

    width, height = im.size
    im_thumb = im.copy()
    im_thumb.thumbnail((x_size, y_size))
    background = Image.new('RGBA', (x_size,y_size), BACKGROUND_COLOR)
    # find aspect ratio for original image
    if(max(width, height)) == width:
        aspect = height/width
        background.paste(im_thumb, (0, round(y_size * (1 - aspect) / 2)))
    else:
        aspect = width/height
        background.paste(im_thumb, (round(x_size * (1 - aspect) / 2), 0))

    return background

# Generate a list of coordinate tuples that represent where icons should be placed for a column layout
# ID: coln
# Parameters: int, bool
def column_coords(num, mirrored):
    if(num > 10):
        print("Warning: Script designed only for quantities of up to 10")        

    coords = list()
    
    # calculate offsets from sides of image
    x_offset = (X_WIDTH - ICON_SIZE * 2) / 2
    y_offset = 0

    if(num <= 5):
        x_offset = (X_WIDTH - ICON_SIZE) / 2
        y_offset = (Y_HEIGHT - num * ICON_SIZE) / 2

    # set up placements relative to other icons
    for i in range(0, min(num, 5)):
        if(mirrored and num > 5):
            coords.append((int(ICON_SIZE + x_offset),int(ICON_SIZE * i + y_offset)))
        else:
            coords.append((int(x_offset),int(ICON_SIZE * i + y_offset)))
    for i in range(5, num):
        if(mirrored):
            coords.append((int(x_offset),int(ICON_SIZE * (i-5) + y_offset)))    
        else:
            coords.append((int(ICON_SIZE + x_offset),int(ICON_SIZE * (i-5) + y_offset)))    

    return coords

# Generate a list of coordinate tuples that represent where icons should be placed for a block layout
# ID: bloc
# Parameters: int, bool
def block_coords(num):
    if(num > 10):
        print("Warning: Script designed only for quantities of up to 10")        

    coords = list()
    
    # calculate offsets from sides of image
    centered_x_offset = (X_WIDTH - ICON_SIZE) / 2
    doubled_x_offset = (X_WIDTH - ICON_SIZE * 2) / 2
    y_offset = (Y_HEIGHT - num * ICON_SIZE // 2) / 2

    # set up placements relative to other icons
    # even
    if(num % 2 == 0):
        for i in range (0, (num // 2)):
            coords.append((int(doubled_x_offset),int(ICON_SIZE * i + y_offset)))
            coords.append((int(ICON_SIZE + doubled_x_offset),int(ICON_SIZE * i + y_offset)))
    else: #odd
        for i in range (0, (num - 1) // 2):
            coords.append((int(doubled_x_offset),int(ICON_SIZE * i + y_offset)))
            coords.append((int(ICON_SIZE + doubled_x_offset),int(ICON_SIZE * i + y_offset)))
        coords.append((int(centered_x_offset),int(ICON_SIZE * ((num-1) // 2) + y_offset)))

    return coords

# Generate a list of coordinate tuples that represent where icons should be placed for a circular layout
# ID: circ
# Parameters: int, bool
def circular_coords(num):
    if(num > 10):
        print("Warning: Script designed only for quantities of up to 10")        

    coords = list()

    center_x = X_WIDTH // 2
    center_y = Y_HEIGHT // 2

    # I LOVE TRIGONOMETRY
    # Calculate distance from origin each icon has to be (radius of circle)
    icon_diagonal = math.sqrt(pow((ICON_SIZE_CIRCULAR / 2), 2) * 2)
    radius = 1/(math.sin(math.radians(18))*2) * icon_diagonal * 1.75

    angle = -90 # start at the top

    # calculate offsets from sides of image
    x_offset = (X_WIDTH - ICON_SIZE_CIRCULAR * 2) / 2
    y_offset = 0

    if(num == 1):
        coords.append((center_x - ICON_SIZE_CIRCULAR // 2, center_y - ICON_SIZE_CIRCULAR // 2))
    else:
        for i in range(0, num):
            coords.append((center_x + int(math.cos(math.radians(angle)) * radius) - ICON_SIZE_CIRCULAR // 2, center_y + int(math.sin(math.radians(angle)) * radius - ICON_SIZE_CIRCULAR // 2))) # I LOVE TRIG
            angle = angle + 360 // num

    return coords
    
# fetch a 100-icon image, or generate it if it doesn't already exist
# Parameters: bool, string, bool
# Returns: PIL Image Object
def fetch_100_image(homo, name, circ):
    if(not homo):
        name = "100Hetero.jpg"
    else:
        if(not name):
            name = random.sample(objectList, 1) 
        # name parameter only used if homogenous
        name = name.split('.')[0] + '.jpg' # split splits a string into a list of parts seperated by a delimiter (in this case .)
    if(os.path.isfile(f"./100_stim/{name}")):
        # open an image:
        im = Image.open(f"./100_stim/{name}").convert("RGBA")
        if(circ):
            return create_im_centered(im, ICON_SIZE_CIRCULAR, ICON_SIZE_CIRCULAR)
        else:
            return create_im_centered(im, ICON_SIZE, ICON_SIZE)

    # creates a square canvas with a white background
    new_im = Image.new('RGB', (500,500), BACKGROUND_COLOR)

    ob = [name.split('.')[0] + '.png']

    # iterate through a 10 by 10 grid with 45 spacing, to place my image
    # allows for a bit of whitespace a the margins
    for i in range(25,475,45):
        for j in range(25,475,45):
            # get an image
            if(not homo):
                ob = random.sample(objectList, 1) 
            # open an image:
            im = Image.open(f"./object_stim/{ob[0]}").convert("RGBA")
            # resize image
            im = create_im_centered(im, 45, 45)
            
            # paste the image at location i,j:
            new_im.paste(im, (i,j), im)

    newImageName = "100" + ob[0].split('.')[0] + ".jpg" # split splits a string into a list of parts seperated by a delimiter (in this case .)
    if(not homo):
        newImageName = "100Hetero.jpg"
    new_im.save(f"./100_stim/{newImageName}")
    im = Image.open(f"./100_stim/{newImageName}").convert("RGBA")
    if(circ):
        return create_im_centered(im, ICON_SIZE_CIRCULAR, ICON_SIZE_CIRCULAR)
    else:
        return create_im_centered(im, ICON_SIZE, ICON_SIZE)

# Generate images with objects comprised of single images
# Parameters: bool, bool, bool, string, string
def generate_images(homo, mirrored, single_icons, placement, homo_icon):
    for i in range(1, 11): # 11 because range in exclusive at the top
        # create image canvas
        new_im = Image.new('RGB', (X_WIDTH,Y_HEIGHT), BACKGROUND_COLOR)

        # if creating homogenous image, pick only 1 object. Otherwise, i objects.
        if(homo):
            # if user passes in an icon, use it
            if(homo_icon):
                ob = [homo_icon]
            else:
                ob = random.sample(objectList, 1)
        else:
            ob = random.sample(objectList, i) 

        # prep each icon (open, resize, etc)
        imagelist = list()

        # open different stimulus based on if we're doing single images or 100-images
        if(single_icons):
            for image in ob:
                im = Image.open(f"./object_stim/{image}").convert("RGBA")
                if(placement == "circ"):
                    im = create_im_centered(im, ICON_SIZE_CIRCULAR, ICON_SIZE_CIRCULAR)
                else:
                    im = create_im_centered(im, ICON_SIZE, ICON_SIZE)
                imagelist.append(im)
        else:
            if(homo):
                imagelist.append(fetch_100_image(True, ob[0], placement == "circ"))
            else:
                imagelist.append(fetch_100_image(False, None, placement == "circ"))

        # determine what placement mode we want, and return list of coordinates
        if placement == "coln":
            locations = column_coords(i, False)
            if(mirrored):
                locations_mirrored = column_coords(i, True)
                new_im_mirrored = Image.new('RGB', (X_WIDTH,Y_HEIGHT), BACKGROUND_COLOR)
        elif placement == "bloc":
            locations = block_coords(i)
            mirrored = False # no functionality for mirroring for this orientation
        elif placement == "circ":
            locations = circular_coords(i)
            mirrored = False # no functionality for mirroring for this orientation
        else:
            print("Placement ID not found, defaulting to nonmirrored column")
            placement = "coln"
            locations = column_coords(i, False)
            mirrored = False
        # place images
        if(homo or not single_icons): # will only place 1 type of image if it's 100hetero or in either case for homo
            image = imagelist[0]

            for b in range(0, i):
                new_im.paste(image, locations.pop(0), image)
                if(mirrored):
                    new_im_mirrored.paste(image, locations_mirrored.pop(0), image)
        else:
            for image in imagelist:
                new_im.paste(image, locations.pop(0), image)
                if(mirrored):
                    new_im_mirrored.paste(image, locations_mirrored.pop(0), image)
        
        # save image
        name_num = i
        if(not single_icons):
            name_num = name_num * 100
        if(homo):
            if(mirrored):
                new_image_name_mirrored = str(name_num) + ob[0].split('.')[0] + "_" + placement + "_mirrored.jpg"
            new_image_name = str(name_num) + ob[0].split('.')[0] + "_" + placement + ".jpg" # split splits a string into a list of parts seperated by a delimiter (in this case .)
        else:
            if(mirrored):
                new_image_name_mirrored = str(name_num) + imageObjectHet + "_" + placement + "_mirrored.jpg"
            new_image_name = str(name_num) + imageObjectHet + "_" + placement + ".jpg"
        new_im.save(f"./out/{new_image_name}")
        if(mirrored):
            new_im_mirrored.save(f"./out/{new_image_name_mirrored}")

# Params: homo, mirrored, single_icons, placement, homo_icon

generate_images(True, False, True, "coln", None)
generate_images(False, False, True, "coln", None)
generate_images(True, False, False, "coln", None)
generate_images(False, False, False, "coln", None)

# generate_images(True, False, True, "bloc", None)
# generate_images(False, False, True, "bloc", None)
# generate_images(True, False, False, "bloc", None)
# generate_images(False, False, False, "bloc", None)

# generate_images(True, False, True, "circ", None)
# generate_images(False, False, True, "circ", None)
# generate_images(True, False, False, "circ", None)
# generate_images(False, False, False, "circ", None)

#TODO: Generate 8 variations on on the 10x10 hetero
#TODO: Generate a version of the 100-images that is full size
#TODO: Cross compare with excel to make sure images line up
